# This Repo contains Terraform code to create Ec2 instance in AWS cloud
